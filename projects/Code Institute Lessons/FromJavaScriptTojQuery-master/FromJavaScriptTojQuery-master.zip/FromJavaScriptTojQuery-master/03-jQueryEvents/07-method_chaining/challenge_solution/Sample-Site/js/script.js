$(document).ready(function() {
 //
 // add your jQuery code here


}); 
