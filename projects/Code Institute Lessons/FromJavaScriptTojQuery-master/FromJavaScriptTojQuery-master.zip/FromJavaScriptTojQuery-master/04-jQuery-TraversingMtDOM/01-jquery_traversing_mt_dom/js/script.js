$(document).ready(function() {
    // put your code here
});